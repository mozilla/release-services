#include "include.h"

int main(void)
{
  Ciao ciao;

  ciao.setName("marco");
  string n = ciao.getName();

  return 0;
}
